# Floating Controls

Floating, customizable on-screen buttons and joysticks that sit over Minecraft Bedrock (or any app)
and send taps / long presses / swipes / holds through an Android AccessibilityService.

## Build the APK from your phone only (GitHub Actions)
1. In your phone browser open github.com, sign in, tap **+ > New repository**, name it, create it.
2. In the repo tap **Add file > Upload files**, choose **FloatingControls.zip** (do NOT unzip it), tap **Commit changes**.
3. Tap **Add file > Create new file**. In the name box type exactly `.github/workflows/build.yml`
   (typing `/` creates the folders). Paste the workflow text from the chat (or from `.github/workflows/build.yml`
   inside the zip) and tap **Commit changes**.
4. Open the **Actions** tab. The "Build APK" run starts by itself (or tap *Build APK > Run workflow*). It takes ~5 minutes.
5. Open the finished run, scroll to **Artifacts**, tap **FloatingControls-debug-apk** to download a zip, extract it
   (Files app) and open `app-debug.apk` to install (allow "install unknown apps" for your browser/Files app).
If the run fails, open it, copy the red error lines and send them back so they can be fixed.

You can also upload the unzipped project instead (then the workflow in `.github/workflows` runs on every push).

## First run
1. Open the app, tap the gear > **Permissions & help**.
2. Grant **Overlay permission** (draw over other apps).
3. Enable **Accessibility > Floating Controls**. If greyed out: Settings > Apps > Floating Controls > ⋮ > *Allow restricted settings*.
4. Edit your layout, then switch on **Floating controls** in the gear menu. A round **FC** button appears:
   tap = show/hide all buttons, drag = move it, long-press = menu (mode In-game/Menus, open editor, stop).

## How actions work
Positions are in % of the screen, so layouts adapt to other screens. Use **Pick on screen** to drag a crosshair.
- Tap, Long press, Repeated taps (while held, or toggled), Swipe, Sequence (tap/long/swipe/wait lines), Hold.
- Hold + *Swipeable* = the held touch follows your finger on the button (camera look).
- Joystick = holds a virtual finger on the game's own joystick position and moves it as you drag.
- System actions: Back, Home, Recents, Notifications, Quick settings, Power menu, Lock screen, Screenshot, show/hide controls, launch an app.

## Four functions per button
Each button has 4 function slots (tabs 1-4 in its settings). Every slot is its own action (tap, hold, swipe, sequence, system...) and all enabled slots fire together when the button is pressed, like a key combo.

## Real keyboard keys (F3, Ctrl, A, E...)
Android does not let normal apps press keys, so this uses the free **Shizuku** helper app (like Key Mapper's ADB mode).
Menu > *Keyboard keys (Shizuku)* shows the status and phone-only setup steps. Then give a button function the action
*Keyboard key* and pick the key. Held while the button is pressed (Ctrl works with another button), or quick press, or toggle.
Use several of the 4 function slots for combos like Ctrl + A. Restart Shizuku after every phone reboot.

## Limits (Android restrictions)
- Real keys need Shizuku running (see above). Without it, use touch or system actions.
- The app cannot detect whether you are "in-game" or "in a menu"; the In-game / In menus visibility is switched manually from the FC button menu.
- Touches are sent in short frames, so there is a small latency; very fast games may feel slightly delayed.
- Exported controlmaps do not include background image files.
