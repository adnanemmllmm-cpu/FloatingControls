package com.example.floatingcontrols;

interface IKeyService {
    void destroy() = 16777114;
    void key(int keyCode, boolean down);
    void releaseAll();
}
