package com.example.floatingcontrols

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.widget.Toast
import kotlin.math.hypot

/** Turns presses on one element into touch actions, according to that element's own configuration. */
class ActRunner(private val ctx: Context, val act: Act, private val onState: () -> Unit) {
    private val cfg = act
    private val h = Handler(Looper.getMainLooper())
    private var slot: TouchEngine.Slot? = null
    private var held = false
    private var on = false
    private var downX = 0f
    private var downY = 0f
    private var baseX = 0f
    private var baseY = 0f
    private var rep: Runnable? = null
    private var seq: Runnable? = null
    private var lastWarn = 0L

    val active: Boolean get() = on || held || seq != null

    private fun engine(): TouchEngine? {
        val e = GestureService.instance?.engine
        if (e == null && SystemClock.uptimeMillis() - lastWarn > 3000) {
            lastWarn = SystemClock.uptimeMillis()
            Toast.makeText(ctx, "Enable the Floating Controls accessibility service first", Toast.LENGTH_LONG).show()
        }
        return e
    }

    // ---- buttons ----
    fun down(x: Float, y: Float) {
        held = true; downX = x; downY = y
        val (sw, sh) = screenSize(ctx)
        val tx = cfg.tx / 100f * sw
        val ty = cfg.ty / 100f * sh
        when (cfg.action) {
            "TAP" -> engine()?.tap(tx, ty, 40)
            "LONG_PRESS" -> engine()?.tap(tx, ty, cfg.duration.toLong())
            "HOLD" -> if (cfg.toggle && slot != null) { stopHold(); on = false }
                      else { startHold(tx, ty); if (cfg.toggle) on = true }
            "REPEAT_TAP" -> if (cfg.toggle && on) { stopRepeat(); on = false }
                            else { startRepeat(tx, ty); if (cfg.toggle) on = true }
            "SWIPE" -> engine()?.swipe(tx, ty, cfg.tx2 / 100f * sw, cfg.ty2 / 100f * sh, cfg.duration.toLong())
            "SEQUENCE" -> if (seq != null) stopSeq() else startSeq()
            "KEY" -> pressKey()
            "SYSTEM" -> system()
        }
        onState()
    }

    fun move(x: Float, y: Float) {
        val s = slot ?: return
        if (cfg.action == "HOLD" && cfg.swipeable) {
            s.tx = baseX + (x - downX)
            s.ty = baseY + (y - downY)
        }
    }

    fun up() {
        held = false
        if (!cfg.toggle) {
            if (cfg.action == "HOLD") stopHold()
            if (cfg.action == "REPEAT_TAP") stopRepeat()
            if (cfg.action == "KEY") releaseKey()
        }
        onState()
    }

    private fun startHold(tx: Float, ty: Float) {
        baseX = tx; baseY = ty
        slot = engine()?.hold(tx, ty)
    }

    private fun stopHold() {
        slot?.let { GestureService.instance?.engine?.release(it) }
        slot = null
    }

    private fun startRepeat(tx: Float, ty: Float) {
        val r = object : Runnable {
            override fun run() {
                engine()?.tap(tx, ty, 30)
                h.postDelayed(this, cfg.interval.toLong().coerceAtLeast(30L))
            }
        }
        rep = r
        h.post(r)
    }

    private fun stopRepeat() { rep?.let { h.removeCallbacks(it) }; rep = null }

    // ---- sequences: lines of "tap X Y", "long X Y ms", "swipe X1 Y1 X2 Y2 ms", "wait ms" (X/Y in %) ----
    private fun startSeq() {
        val steps = cfg.sequence.lines().map { it.trim().split(Regex("\\s+")) }.filter { it[0].isNotEmpty() }
        if (steps.isEmpty()) return
        var i = 0
        on = cfg.toggle
        val r = object : Runnable {
            override fun run() {
                if (i >= steps.size) {
                    if (cfg.toggle && on) i = 0 else { seq = null; on = false; onState(); return }
                }
                val s = steps[i++]
                var wait = 150L
                try {
                    val e = engine()
                    val (sw, sh) = screenSize(ctx)
                    fun fx(k: Int) = s[k].toFloat() / 100f * sw
                    fun fy(k: Int) = s[k].toFloat() / 100f * sh
                    when (s[0].lowercase()) {
                        "tap" -> { e?.tap(fx(1), fy(2), 40); wait = 200L }
                        "long" -> { val ms = s.getOrNull(3)?.toLongOrNull() ?: 800L; e?.tap(fx(1), fy(2), ms); wait = ms + 150L }
                        "swipe" -> { val ms = s.getOrNull(5)?.toLongOrNull() ?: 400L; e?.swipe(fx(1), fy(2), fx(3), fy(4), ms); wait = ms + 150L }
                        "wait" -> wait = s.getOrNull(1)?.toLongOrNull() ?: 500L
                    }
                } catch (ex: Exception) { }
                h.postDelayed(this, wait)
            }
        }
        seq = r
        h.post(r)
    }

    private fun stopSeq() { seq?.let { h.removeCallbacks(it) }; seq = null; on = false }

    // ---- real keyboard keys (through Shizuku) ----
    private var keyOn = false

    private fun keyCode() = KeyEvent.keyCodeFromString("KEYCODE_" + cfg.key)

    private fun pressKey() {
        val code = keyCode()
        if (code == KeyEvent.KEYCODE_UNKNOWN) return
        KeyBridge.ensure(ctx)
        if (cfg.toggle && keyOn) { KeyBridge.key(code, false); keyOn = false; on = false; return }
        if (!KeyBridge.key(code, true)) {
            if (SystemClock.uptimeMillis() - lastWarn > 3000) {
                lastWarn = SystemClock.uptimeMillis()
                Toast.makeText(ctx, "Keyboard keys need Shizuku: open the app menu > Keyboard keys", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (cfg.keyTap) h.postDelayed({ KeyBridge.key(code, false) }, 40)
        else { keyOn = true; if (cfg.toggle) on = true }
    }

    private fun releaseKey() {
        if (keyOn) { KeyBridge.key(keyCode(), false); keyOn = false }
    }

    // ---- system actions ----
    private fun system() {
        when (cfg.system) {
            "TOGGLE_CONTROLS" -> OverlayService.instance?.toggleShown()
            "LAUNCH_APP" -> {
                val i = ctx.packageManager.getLaunchIntentForPackage(cfg.pkg)
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
                else Toast.makeText(ctx, "App not found: ${cfg.pkg}", Toast.LENGTH_SHORT).show()
            }
            else -> if (GestureService.instance?.global(cfg.system) != true) engine()
        }
    }

    // ---- joystick: the virtual finger is held on the game's own joystick and moved with yours ----
    private var jx = 0f
    private var jy = 0f

    fun joyStart() {
        val (sw, sh) = screenSize(ctx)
        jx = cfg.tx / 100f * sw; jy = cfg.ty / 100f * sh
        slot = engine()?.hold(jx, jy)
        held = true; onState()
    }

    fun joyMove(nx: Float, ny: Float, reachDp: Int) {
        val s = slot ?: return
        val r = ctx.dp(reachDp)
        val d = hypot(nx, ny)
        val dead = 0.12f                       // small dead zone, then smooth ramp to full reach
        if (d < dead) { s.tx = jx; s.ty = jy; return }
        val m = ((d - dead) / (1f - dead)).coerceIn(0f, 1f)
        s.tx = jx + nx / d * m * r
        s.ty = jy + ny / d * m * r
    }

    fun joyEnd() { stopHold(); held = false; onState() }

    fun destroy() { stopRepeat(); stopSeq(); stopHold(); releaseKey(); held = false; on = false }
}

/** One Runner per button: fires every enabled function slot together. */
class Runner(ctx: Context, private val cfg: Btn, onState: () -> Unit) {
    private val subs = (0..3).map { ActRunner(ctx, cfg.act(it), onState) }.filter { it.act.action != "NONE" }
    private val joy = ActRunner(ctx, cfg.act(0), onState)

    val active: Boolean get() = if (cfg.kind == "joystick") joy.active else subs.any { it.active }

    fun down(x: Float, y: Float) { subs.forEach { it.down(x, y) } }
    fun move(x: Float, y: Float) { subs.forEach { it.move(x, y) } }
    fun up() { subs.forEach { it.up() } }

    fun joyStart() = joy.joyStart()
    fun joyMove(nx: Float, ny: Float) = joy.joyMove(nx, ny, cfg.reach)
    fun joyEnd() = joy.joyEnd()

    fun destroy() { subs.forEach { it.destroy() }; joy.destroy() }
}
