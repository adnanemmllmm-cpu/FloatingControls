package com.example.floatingcontrols

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import rikka.shizuku.Shizuku
import java.lang.reflect.Method

val KEY_NAMES: List<String> = ('A'..'Z').map { it.toString() } + (0..9).map { it.toString() } +
    (1..12).map { "F$it" } + listOf(
        "CTRL_LEFT", "CTRL_RIGHT", "SHIFT_LEFT", "SHIFT_RIGHT", "ALT_LEFT", "ALT_RIGHT",
        "SPACE", "ENTER", "ESCAPE", "TAB", "DEL", "FORWARD_DEL",
        "DPAD_UP", "DPAD_DOWN", "DPAD_LEFT", "DPAD_RIGHT", "PAGE_UP", "PAGE_DOWN", "MOVE_HOME", "MOVE_END",
        "INSERT", "CAPS_LOCK", "GRAVE", "MINUS", "EQUALS", "COMMA", "PERIOD", "SLASH", "SEMICOLON",
        "APOSTROPHE", "LEFT_BRACKET", "RIGHT_BRACKET", "BACKSLASH"
    )

/** Runs inside the Shizuku "shell" process, where Android allows injecting real key events. */
class KeyService : IKeyService.Stub() {
    private var meta = 0
    private val downTimes = HashMap<Int, Long>()
    private var target: Any? = null
    private var inject: Method? = null

    init {
        try {
            val c = Class.forName("android.hardware.input.InputManager")
            target = c.getMethod("getInstance").invoke(null)
            inject = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (e: Throwable) {
            try {
                val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java)
                    .invoke(null, "input") as IBinder
                val s = Class.forName("android.hardware.input.IInputManager\$Stub")
                    .getMethod("asInterface", IBinder::class.java).invoke(null, b)
                target = s
                inject = s!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            } catch (e2: Throwable) { }
        }
    }

    private fun flags(k: Int): Int = when (k) {
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_CTRL_RIGHT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_RIGHT_ON
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_SHIFT_RIGHT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_RIGHT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_ALT_RIGHT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_RIGHT_ON
        else -> 0
    }

    override fun destroy() { releaseAll(); System.exit(0) }

    override fun key(keyCode: Int, isDown: Boolean) {
        val f = flags(keyCode)
        val now = SystemClock.uptimeMillis()
        if (isDown) {
            meta = meta or f
            if (!downTimes.containsKey(keyCode)) downTimes[keyCode] = now
        }
        val dt = downTimes[keyCode] ?: now
        val e = KeyEvent(dt, now, if (isDown) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP,
            keyCode, 0, meta, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
        try { inject?.invoke(target, e, 0) } catch (ex: Throwable) { }
        if (!isDown) { meta = meta and f.inv(); downTimes.remove(keyCode) }
    }

    override fun releaseAll() { for (k in downTimes.keys.toList()) key(k, false) }
}

/** App-side link to the Shizuku key service. */
object KeyBridge {
    private var svc: IKeyService? = null
    private var binding = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = if (b != null && b.pingBinder()) IKeyService.Stub.asInterface(b) else null
            binding = false
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null; binding = false }
    }

    fun ready(): Boolean = svc != null

    fun ensure(ctx: Context) {
        try {
            if (svc != null || binding) return
            if (!Shizuku.pingBinder()) return
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return
            binding = true
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, KeyService::class.java.name))
                .daemon(false).processNameSuffix("keys").debuggable(false).version(1)
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) { binding = false }
    }

    fun key(code: Int, down: Boolean): Boolean {
        val s = svc ?: return false
        return try { s.key(code, down); true } catch (e: Exception) { svc = null; false }
    }
}
