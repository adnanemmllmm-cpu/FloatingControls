package com.example.floatingcontrols

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.min

/** Draws every button as its own overlay window, so touches outside the buttons still reach the game. */
class OverlayService : Service() {
    companion object {
        var instance: OverlayService? = null
        const val CH = "fc"
    }

    private class Entry(val view: ElementView, val lp: WindowManager.LayoutParams) { var attached = false }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val entries = ArrayList<Entry>()
    private var fab: FabView? = null
    private var fabLp: WindowManager.LayoutParams? = null
    private var fabAttached = false
    private var quick: View? = null
    private var shown = true
    private var gameMode = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { Store.setEnabled(this, false); stopSelf() }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); build() }

    override fun onDestroy() {
        clear()
        instance = null
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Floating controls", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Floating controls are on")
            .setContentText("Tap to open the editor")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    fun reload() { build() }

    fun toggleShown() {
        shown = !shown
        fab?.on = shown
        fab?.invalidate()
        applyVisibility()
    }

    private fun overlayParams(w: Int, hh: Int, x: Int, y: Int, flags: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH or flags,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x; p.y = y
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }

    private fun build() {
        clear()
        if (!Settings.canDrawOverlays(this)) return
        KeyBridge.ensure(this)
        val list = try { Store.load(this, Store.active(this)) } catch (e: Exception) { mutableListOf() }
        val (sw, sh) = screenSize(this)
        for (b in list) {
            val v = ElementView(this, b, ElementView.LIVE)
            v.runner = Runner(this, b) { v.invalidate() }
            v.refresh()
            val flags = if (b.passThru) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
            entries.add(Entry(v, overlayParams(dp(b.w), dp(b.h), (b.x * sw).toInt(), (b.y * sh).toInt(), flags)))
        }
        makeFab(sw, sh)
        applyVisibility()
    }

    private fun applyVisibility() {
        for (e in entries) {
            val c = e.view.cfg
            val want = shown && ((gameMode && c.inGame) || (!gameMode && c.inMenus))
            if (want && !e.attached) {
                try { wm.addView(e.view, e.lp); e.attached = true } catch (ex: Exception) { }
            } else if (!want && e.attached) {
                e.view.runner?.destroy()
                try { wm.removeView(e.view) } catch (ex: Exception) { }
                e.attached = false
            }
        }
        // keep the main button on top of everything
        val f = fab ?: return
        if (fabAttached) { try { wm.removeView(f) } catch (ex: Exception) { }; fabAttached = false }
        try { wm.addView(f, fabLp); fabAttached = true } catch (ex: Exception) { }
    }

    private fun clear() {
        dismissQuick()
        for (e in entries) {
            e.view.runner?.destroy()
            if (e.attached) try { wm.removeView(e.view) } catch (ex: Exception) { }
        }
        entries.clear()
        fab?.let { if (fabAttached) try { wm.removeView(it) } catch (ex: Exception) { } }
        fab = null; fabAttached = false
    }

    // ---- main floating button: tap = show/hide all, drag = move, long-press = quick menu ----
    private fun makeFab(sw: Int, sh: Int) {
        val v = FabView(this)
        v.on = shown
        val size = dp(46)
        val (fx, fy) = Store.mainPos(this)
        val lp = overlayParams(size, size, (fx * sw).toInt(), (fy * sh).toInt(), 0)
        fabLp = lp
        val slop = dp(8)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        var moved = false; var longFired = false
        val longTask = Runnable { longFired = true; showQuick() }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; longFired = false
                    h.postDelayed(longTask, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && hypot(e.rawX - sx, e.rawY - sy) > slop) { moved = true; h.removeCallbacks(longTask) }
                    if (moved) {
                        lp.x = (ox + e.rawX - sx).toInt().coerceIn(0, maxOf(0, sw - size))
                        lp.y = (oy + e.rawY - sy).toInt().coerceIn(0, maxOf(0, sh - size))
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(longTask)
                    if (moved) Store.setMainPos(this, lp.x / sw.toFloat(), lp.y / sh.toFloat())
                    else if (!longFired) toggleShown()
                }
                MotionEvent.ACTION_CANCEL -> h.removeCallbacks(longTask)
            }
            true
        }
        fab = v
    }

    private fun showQuick() {
        dismissQuick()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0xEE212121.toInt())
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        fun item(t: String, f: () -> Unit) {
            val tv = TextView(this)
            tv.text = t; tv.textSize = 16f; tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.setOnClickListener { dismissQuick(); f() }
            box.addView(tv)
        }
        item(if (gameMode) "Mode: In-game  (tap to switch to Menus)" else "Mode: Menus  (tap to switch to In-game)") {
            gameMode = !gameMode; applyVisibility()
        }
        item("Choose keyboard") {
            try {
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker()
            } catch (e: Exception) {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        item("Open editor") {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        item("Stop floating controls") { Store.setEnabled(this, false); stopSelf() }
        item("Close") { }
        box.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) dismissQuick(); false }
        val (sw, sh) = screenSize(this)
        val fl = fabLp
        val p = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            min(fl?.x ?: 0, maxOf(0, sw - dp(300))), min((fl?.y ?: 0) + dp(54), maxOf(0, sh - dp(220))),
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
        try { wm.addView(box, p); quick = box } catch (ex: Exception) { }
    }

    private fun dismissQuick() {
        quick?.let { try { wm.removeView(it) } catch (ex: Exception) { } }
        quick = null
    }
}

class FabView(ctx: android.content.Context) : View(ctx) {
    var on = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = min(width, height) / 2f
        p.style = Paint.Style.FILL
        p.color = if (on) 0xDD00796B.toInt() else 0xDD424242.toInt()
        c.drawCircle(r, r, r - 2, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.WHITE
        c.drawCircle(r, r, r - 4, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.8f
        c.drawText("FC", r, r - (p.ascent() + p.descent()) / 2, p)
    }
}
