package com.example.floatingcontrols

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A small on-screen keyboard that also receives key requests from the floating buttons and
 * sends them to the app that currently has keyboard focus through the normal InputConnection.
 */
class KeyboardService : InputMethodService() {
    companion object { var instance: KeyboardService? = null }

    private var meta = 0
    private val downTimes = HashMap<Int, Long>()
    private var shift = false
    private val letters = ArrayList<Pair<TextView, Char>>()

    override fun onCreate() { super.onCreate(); instance = this }

    override fun onDestroy() {
        releaseAll()
        instance = null
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun flags(k: Int): Int = when (k) {
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_CTRL_RIGHT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_RIGHT_ON
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_SHIFT_RIGHT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_RIGHT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_ALT_RIGHT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_RIGHT_ON
        else -> 0
    }

    /** Returns false when no app currently has an input connection to receive the key. */
    fun sendKey(code: Int, down: Boolean): Boolean {
        val ic = currentInputConnection ?: return false
        val f = flags(code)
        val now = SystemClock.uptimeMillis()
        if (down) {
            meta = meta or f
            if (!downTimes.containsKey(code)) downTimes[code] = now
        }
        val dt = downTimes[code] ?: now
        val e = KeyEvent(dt, now, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, meta,
            KeyCharacterMap.VIRTUAL_KEYBOARD, 0, KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE,
            InputDevice.SOURCE_KEYBOARD)
        val ok = ic.sendKeyEvent(e)
        if (!down) { meta = meta and f.inv(); downTimes.remove(code) }
        return ok
    }

    fun releaseAll() { for (k in downTimes.keys.toList()) sendKey(k, false) }

    // ---- the keyboard you can actually type with ----
    private fun mk(label: String, weight: Float, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label; t.textSize = 18f; t.gravity = Gravity.CENTER; t.setTextColor(Color.WHITE)
        t.setBackgroundColor(0xFF3A3A3A.toInt())
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(0, dp(44), weight).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        return t
    }

    private fun typeChar(c: Char) {
        val s = if (shift && c.isLetter()) c.uppercaseChar() else c
        currentInputConnection?.commitText(s.toString(), 1)
        if (shift) { shift = false; refreshCase() }
    }

    private fun refreshCase() {
        for ((t, c) in letters) t.text = (if (shift) c.uppercaseChar() else c).toString()
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    override fun onCreateInputView(): View {
        letters.clear()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF202020.toInt())
        root.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (rowChars in listOf("1234567890", "qwertyuiop", "asdfghjkl")) {
            val row = newRow()
            for (c in rowChars) {
                val t = mk(c.toString(), 1f) { typeChar(c) }
                if (c.isLetter()) letters.add(Pair(t, c))
                row.addView(t)
            }
            root.addView(row)
        }
        val r3 = newRow()
        r3.addView(mk("\u21E7", 1.5f) { shift = !shift; refreshCase() })
        for (c in "zxcvbnm") {
            val t = mk(c.toString(), 1f) { typeChar(c) }
            letters.add(Pair(t, c))
            r3.addView(t)
        }
        r3.addView(mk("\u232B", 1.5f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(r3)
        val r4 = newRow()
        r4.addView(mk("\u2328", 1.5f) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        r4.addView(mk(",", 1f) { typeChar(',') })
        r4.addView(mk("space", 5f) { currentInputConnection?.commitText(" ", 1) })
        r4.addView(mk(".", 1f) { typeChar('.') })
        r4.addView(mk("\u23CE", 1.5f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) })
        root.addView(r4)
        return root
    }
}
