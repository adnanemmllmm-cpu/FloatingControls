package com.example.floatingcontrols

import android.content.Context

val KEY_NAMES: List<String> = ('A'..'Z').map { it.toString() } + (0..9).map { it.toString() } +
    (1..12).map { "F$it" } + listOf(
        "CTRL_LEFT", "CTRL_RIGHT", "SHIFT_LEFT", "SHIFT_RIGHT", "ALT_LEFT", "ALT_RIGHT",
        "SPACE", "ENTER", "ESCAPE", "TAB", "DEL", "FORWARD_DEL",
        "DPAD_UP", "DPAD_DOWN", "DPAD_LEFT", "DPAD_RIGHT", "PAGE_UP", "PAGE_DOWN", "MOVE_HOME", "MOVE_END",
        "INSERT", "CAPS_LOCK", "GRAVE", "MINUS", "EQUALS", "COMMA", "PERIOD", "SLASH", "SEMICOLON",
        "APOSTROPHE", "LEFT_BRACKET", "RIGHT_BRACKET", "BACKSLASH"
    )

/** Sends keys through this app's own keyboard (input method), like Key Mapper's keyboard. */
object KeyBridge {
    fun ensure(ctx: Context) {}
    fun ready(): Boolean = KeyboardService.instance != null
    fun key(code: Int, down: Boolean): Boolean = KeyboardService.instance?.sendKey(code, down) ?: false
}
