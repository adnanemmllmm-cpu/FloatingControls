plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.floatingcontrols"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.floatingcontrols"
        minSdk = 29
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
