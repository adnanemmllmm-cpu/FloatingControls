package com.example.floatingcontrols

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/** Performs the touch gestures / system actions. Only active while the user has enabled it in Settings. */
class GestureService : AccessibilityService() {
    companion object { var instance: GestureService? = null }

    val engine by lazy { TouchEngine(this) }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun global(name: String): Boolean {
        val a = when (name) {
            "BACK" -> GLOBAL_ACTION_BACK
            "HOME" -> GLOBAL_ACTION_HOME
            "RECENTS" -> GLOBAL_ACTION_RECENTS
            "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
            "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
            "POWER_DIALOG" -> GLOBAL_ACTION_POWER_DIALOG
            "LOCK_SCREEN" -> GLOBAL_ACTION_LOCK_SCREEN
            "TAKE_SCREENSHOT" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return false
        }
        return performGlobalAction(a)
    }
}

/**
 * Multi-touch engine. Android only lets one gesture be "in progress" per dispatch, so every active
 * finger (joystick, held button, tap, swipe...) is a Slot and all slots are sent together in short
 * continued-stroke frames. This is what makes several buttons usable at the same time.
 */
class TouchEngine(private val svc: AccessibilityService) {
    class Slot(var cx: Float, var cy: Float) {
        var tx = cx; var ty = cy
        var ex = cx; var ey = cy
        var last: GestureDescription.StrokeDescription? = null
        var finishing = false
        var finalSent = false
        var onFrame: ((Long) -> Unit)? = null
    }

    private val slots = ArrayList<Slot>()
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private val frame = 40L

    fun hold(x: Float, y: Float): Slot { val s = Slot(x, y); add(s); return s }
    fun release(s: Slot) { s.finishing = true }

    fun tap(x: Float, y: Float, ms: Long) {
        val s = Slot(x, y)
        val t0 = SystemClock.uptimeMillis()
        s.onFrame = { n -> if (n - t0 >= ms) s.finishing = true }
        add(s)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val s = Slot(x1, y1)
        val t0 = SystemClock.uptimeMillis()
        val dur = if (ms < 1) 1L else ms
        s.onFrame = { n ->
            val f = ((n - t0).toFloat() / dur).coerceIn(0f, 1f)
            s.tx = x1 + (x2 - x1) * f
            s.ty = y1 + (y2 - y1) * f
            if (f >= 1f) s.finishing = true
        }
        add(s)
    }

    private fun add(s: Slot) { slots.add(s); pump() }

    private fun pump() {
        if (busy || slots.isEmpty()) return
        val (sw, sh) = screenSize(svc)
        val now = SystemClock.uptimeMillis()
        val b = GestureDescription.Builder()
        val sent = ArrayList<Slot>()
        for (s in slots) {
            if (sent.size >= GestureDescription.getMaxStrokeCount()) break
            s.onFrame?.invoke(now)
            s.tx = s.tx.coerceIn(0f, sw - 1f)
            s.ty = s.ty.coerceIn(0f, sh - 1f)
            val p = Path()
            p.moveTo(s.cx, s.cy)
            if (s.tx != s.cx || s.ty != s.cy) p.lineTo(s.tx, s.ty)
            val cont = !s.finishing
            val prev = s.last
            val sd = if (prev == null) GestureDescription.StrokeDescription(p, 0L, frame, cont)
                     else prev.continueStroke(p, 0L, frame, cont)
            s.last = sd
            s.ex = s.tx; s.ey = s.ty
            s.finalSent = !cont
            b.addStroke(sd)
            sent.add(s)
        }
        busy = true
        val ok = try {
            svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { done(sent, true) }
                override fun onCancelled(g: GestureDescription?) { done(sent, false) }
            }, handler)
        } catch (e: Exception) { false }
        if (!ok) { busy = false; slots.clear() }
    }

    private fun done(sent: List<Slot>, ok: Boolean) {
        busy = false
        if (!ok) { slots.clear(); return }
        for (s in sent) {
            s.cx = s.ex; s.cy = s.ey
            if (s.finalSent) slots.remove(s)
        }
        handler.post { pump() }
    }
}
