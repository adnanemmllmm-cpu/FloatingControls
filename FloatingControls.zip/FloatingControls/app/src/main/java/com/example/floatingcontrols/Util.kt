package com.example.floatingcontrols

import android.content.Context
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.SeekBar

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val TEAL = 0xFF80CBC4.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Full physical screen size in pixels (current rotation). */
@Suppress("DEPRECATION")
fun screenSize(c: Context): Pair<Int, Int> {
    val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        Pair(b.width(), b.height())
    } else {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        Pair(m.widthPixels, m.heightPixels)
    }
}

class Watcher(private val f: (String) -> Unit) : TextWatcher {
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
}

class Seek(private val f: (Int) -> Unit) : SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) f(p) }
    override fun onStartTrackingTouch(s: SeekBar?) {}
    override fun onStopTrackingTouch(s: SeekBar?) {}
}
