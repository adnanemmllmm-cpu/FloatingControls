# Floating Controls

Floating, customizable on-screen buttons and joysticks that sit over Minecraft Bedrock (or any app)
and send taps / long presses / swipes / holds through an Android AccessibilityService.

## Build the APK from your phone only (GitHub Actions)
1. In your phone browser open github.com, sign in, tap **+ > New repository**, name it, create it.
2. In the repo tap **Add file > Upload files**, choose **FloatingControls.zip** (do NOT unzip it), tap **Commit changes**.
3. Tap **Add file > Create new file**. In the name box type exactly `.github/workflows/build.yml`
   (typing `/` creates the folders). Paste the workflow text from the chat (or from `.github/workflows/build.yml`
   inside the zip) and tap **Commit changes**.
4. Open the **Actions** tab. The "Build APK" run starts by itself (or tap *Build APK > Run workflow*). It takes ~5 minutes.
5. Open the finished run, scroll to **Artifacts**, tap **FloatingControls-debug-apk** to download a zip, extract it
   (Files app) and open `app-debug.apk` to install (allow "install unknown apps" for your browser/Files app).
If the run fails, open it, copy the red error lines and send them back so they can be fixed.

You can also upload the unzipped project instead (then the workflow in `.github/workflows` runs on every push).

## First run
1. Open the app, tap the gear > **Permissions & help**.
2. Grant **Overlay permission** (draw over other apps).
3. Enable **Accessibility > Floating Controls**. If greyed out: Settings > Apps > Floating Controls > ⋮ > *Allow restricted settings*.
4. Edit your layout, then switch on **Floating controls** in the gear menu. A round **FC** button appears:
   tap = show/hide all buttons, drag = move it, long-press = menu (mode In-game/Menus, open editor, stop).

## How actions work
Positions are in % of the screen, so layouts adapt to other screens. Use **Pick on screen** to drag a crosshair.
- Tap, Long press, Repeated taps (while held, or toggled), Swipe, Sequence (tap/long/swipe/wait lines), Hold.
- Hold + *Swipeable* = the held touch follows your finger on the button (camera look).
- Joystick = holds a virtual finger on the game's own joystick position and moves it as you drag.
- System actions: Back, Home, Recents, Notifications, Quick settings, Power menu, Lock screen, Screenshot, show/hide controls, launch an app.

## Four functions per button
Each button has 4 function slots (tabs 1-4 in its settings). Every slot is its own action (tap, hold, swipe, sequence, system...) and all enabled slots fire together when the button is pressed, like a key combo.

## Delay between functions
Functions 2-4 of a button each have *Delay after the previous function (ms)*: 0 = together, 50 = 50 ms after the previous one, etc.
If you release the button early, functions still waiting keep going and fire as a quick press, so the chain always completes.

## Swipeable buttons
Turn on *Swipeable* for a button: a finger that starts on it can slide onto other swipeable buttons; the old one is released
and the new one is pressed (release when the finger leaves all of them). A Hold function also has *Follow finger* (camera look).

## Importing Pojav control maps
Menu > *Import controlmap* reads this app's files and PojavLauncher control maps (`mControlDataList`...).
Positions/sizes/colors/opacity/swipeable/toggle are converted, keys become *Keyboard key* functions (up to 4 per button),
GUI becomes show/hide controls, mouse-left becomes a Hold at screen centre, mouse-right a Tap at screen centre,
the Pojav joystick becomes a W A S D joystick. Keyboard / virtual-mouse / scroll buttons keep their look but get no action.

## Real keyboard keys (F3, Ctrl, A, E...)
This app includes its own keyboard (an Android input method, like Key Mapper's). Menu > *Keyboard keys setup*:
1. Enable "Floating Controls keyboard" in Android settings. 2. Choose it as the active keyboard.
Then give a button function the action *Keyboard key* and pick the key. It is held while the button is pressed
(so Ctrl works together with another button), or use *Quick press*, or *Toggleable*.
Use several of the 4 function slots for combos like Ctrl + A.
Switch back to your normal keyboard with the keyboard key on its bottom-left, or the FC button's long-press menu.
Keys only reach an app that has a text/keyboard input focused (Android rule); games with no input focus cannot receive them.

## Limits (Android restrictions)
- Keyboard keys need the built-in keyboard selected and an app/game with keyboard input focus. Otherwise use touch or system actions.
- The app cannot detect whether you are "in-game" or "in a menu"; the In-game / In menus visibility is switched manually from the FC button menu.
- Touches are sent in short frames, so there is a small latency; very fast games may feel slightly delayed.
- Exported controlmaps do not include background image files.
