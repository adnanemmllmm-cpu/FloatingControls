package com.example.floatingcontrols

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import java.util.Locale
import kotlin.math.*

/** Draws one button/joystick. Used in the editor (EDIT), preview (PREVIEW) and the overlay (LIVE). */
class ElementView(ctx: Context, var cfg: Btn, var mode: Int) : View(ctx) {
    companion object { const val EDIT = 0; const val PREVIEW = 1; const val LIVE = 2 }

    var runner: Runner? = null
    var onSelect: ((Btn) -> Unit)? = null
    var onChange: ((Btn) -> Unit)? = null
    var picked = false
        set(v) { field = v; invalidate() }

    private var down = false
    private var knobX = 0f
    private var knobY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private var bmp: Bitmap? = null
    private var bmpPath = ""
    private val density = ctx.resources.displayMetrics.density

    fun refresh() {
        val a = cfg.opacity.coerceIn(10, 100) / 100f
        alpha = if (mode == EDIT) max(a, 0.4f) else a
        if (cfg.image != bmpPath) {
            bmpPath = cfg.image
            bmp = if (bmpPath.isEmpty()) null else try { BitmapFactory.decodeFile(bmpPath) } catch (e: Exception) { null }
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = min(w, h)
        val sw = cfg.strokeW / 100f * m * 0.2f
        val hs = sw / 2f
        rect.set(hs, hs, w - hs, h - hs)
        val joy = cfg.kind == "joystick"
        val r = if (cfg.shape == "circle" || joy) m / 2f else cfg.corner / 100f * m / 2f
        val lit = down || (runner?.active == true)

        paint.style = Paint.Style.FILL
        paint.color = cfg.bg
        c.drawRoundRect(rect, r, r, paint)

        bmp?.let { b ->
            c.save()
            path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
            c.clipPath(path)
            val s = max(w / b.width, h / b.height)
            val dw = b.width * s
            val dh = b.height * s
            paint.color = Color.WHITE
            c.drawBitmap(b, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), paint)
            c.restore()
        }

        if (joy) {
            paint.color = cfg.fg
            paint.alpha = 200
            c.drawCircle(w / 2 + knobX, h / 2 + knobY, m * 0.2f, paint)
            paint.alpha = 255
        } else {
            paint.color = cfg.fg
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = m * 0.3f
            val tw = paint.measureText(cfg.name)
            if (tw > w * 0.88f && tw > 0f) paint.textSize = paint.textSize * w * 0.88f / tw
            c.drawText(cfg.name, w / 2, h / 2 - (paint.ascent() + paint.descent()) / 2, paint)
        }

        if (lit) {
            paint.color = 0x55FFFFFF.toInt()
            c.drawRoundRect(rect, r, r, paint)
        }
        if (sw > 0.5f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = sw
            paint.color = cfg.stroke
            c.drawRoundRect(rect, r, r, paint)
        }
        if (mode == EDIT && picked) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2 * density
            paint.color = TEAL
            c.drawRect(1f, 1f, w - 1, h - 1, paint)
            paint.style = Paint.Style.FILL
            val hd = 22 * density
            path.reset(); path.moveTo(w, h - hd); path.lineTo(w, h); path.lineTo(w - hd, h); path.close()
            c.drawPath(path, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = if (mode == EDIT) editTouch(e) else playTouch(e)

    // ---- editor: drag to move, drag the corner triangle to resize ----
    private var sRawX = 0f; private var sRawY = 0f
    private var sX = 0f; private var sY = 0f
    private var sW = 0; private var sH = 0
    private var resizing = false
    private var moved = false

    private fun editTouch(e: MotionEvent): Boolean {
        val par = parent as? View ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                sRawX = e.rawX; sRawY = e.rawY; sX = x; sY = y; sW = width; sH = height
                val hd = 28 * density
                resizing = e.x > width - hd && e.y > height - hd
                moved = false
                onSelect?.invoke(cfg)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - sRawX
                val dy = e.rawY - sRawY
                if (!moved && hypot(dx, dy) > 8 * density) moved = true
                if (moved) {
                    if (resizing) {
                        val lo = 24 * density
                        var nw = (sW + dx).coerceIn(lo, max(lo, par.width - sX))
                        var nh = (sH + dy).coerceIn(lo, max(lo, par.height - sY))
                        if (cfg.shape == "square" || cfg.shape == "circle" || cfg.kind == "joystick") {
                            val s = min(nw, nh); nw = s; nh = s
                        }
                        val lp = layoutParams
                        lp.width = nw.toInt(); lp.height = nh.toInt()
                        layoutParams = lp
                        cfg.w = (nw / density).roundToInt()
                        cfg.h = (nh / density).roundToInt()
                    } else {
                        x = (sX + dx).coerceIn(0f, max(0f, par.width - width.toFloat()))
                        y = (sY + dy).coerceIn(0f, max(0f, par.height - height.toFloat()))
                        cfg.x = x / par.width
                        cfg.y = y / par.height
                    }
                    onChange?.invoke(cfg)
                }
            }
        }
        return true
    }

    // ---- preview / live ----
    private fun moveKnob(e: MotionEvent): Pair<Float, Float> {
        val maxR = min(width, height) / 2f * 0.6f
        var dx = e.x - width / 2f
        var dy = e.y - height / 2f
        val d = hypot(dx, dy)
        if (d > maxR) { dx = dx / d * maxR; dy = dy / d * maxR }
        knobX = dx; knobY = dy
        return Pair(dx / maxR, dy / maxR)
    }

    var swipeHit: ((Float, Float) -> ElementView?)? = null
    private var cur: ElementView? = null

    fun virtualDown(lx: Float, ly: Float) { down = true; runner?.down(lx, ly); invalidate() }
    fun virtualUp() { down = false; runner?.up(); invalidate() }

    private fun followsFinger(): Boolean = (0..3).any { val a = cfg.act(it); a.action == "HOLD" && a.swipeable }

    /** Swipeable: the finger that started on this button can slide onto other swipeable buttons. */
    private fun swipeMove(e: MotionEvent) {
        val hit = swipeHit?.invoke(e.rawX, e.rawY)
        val c = cur
        if (hit != null) {
            if (hit !== c) {
                c?.virtualUp()
                hit.virtualDown(hit.width / 2f, hit.height / 2f)
                cur = hit
            } else if (hit === this) runner?.move(e.x, e.y)
        } else if (c != null && !followsFinger()) {
            c.virtualUp(); cur = null
        } else if (c === this) runner?.move(e.x, e.y)
    }

    private fun playTouch(e: MotionEvent): Boolean {
        val joy = cfg.kind == "joystick"
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (joy) { down = true; val (nx, ny) = moveKnob(e); runner?.joyStart(); runner?.joyMove(nx, ny) }
                else { cur = this; virtualDown(e.x, e.y) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joy) { val (nx, ny) = moveKnob(e); runner?.joyMove(nx, ny) }
                else if (cfg.slide && swipeHit != null) swipeMove(e)
                else runner?.move(e.x, e.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (joy) { down = false; knobX = 0f; knobY = 0f; runner?.joyEnd() }
                else { cur?.virtualUp(); cur = null; down = false }
            }
        }
        invalidate()
        return true
    }
}

/** The editor canvas: positions are stored as fractions so layouts adapt to any screen. */
class Workspace(ctx: Context) : FrameLayout(ctx) {
    private val grid = Paint().apply { color = 0x14FFFFFF; strokeWidth = 1f }
    init { setWillNotDraw(false); setBackgroundColor(0xFF161616.toInt()) }

    fun views(): List<ElementView> = (0 until childCount).mapNotNull { getChildAt(it) as? ElementView }

    override fun onDraw(c: Canvas) {
        val step = context.dp(40).toFloat()
        var gx = 0f
        while (gx < width) { c.drawLine(gx, 0f, gx, height.toFloat(), grid); gx += step }
        var gy = 0f
        while (gy < height) { c.drawLine(0f, gy, width.toFloat(), gy, grid); gy += step }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        views().forEach { place(it) }
    }

    fun place(v: ElementView) {
        val lp = v.layoutParams
        lp.width = context.dp(v.cfg.w); lp.height = context.dp(v.cfg.h)
        v.layoutParams = lp
        if (width > 0 && height > 0) {
            v.x = (v.cfg.x * width).coerceIn(0f, max(0f, (width - lp.width).toFloat()))
            v.y = (v.cfg.y * height).coerceIn(0f, max(0f, (height - lp.height).toFloat()))
        }
    }
}

/** Full-screen crosshair picker used to choose touch coordinates by dragging a target. */
class PickerView(ctx: Context, var fx: Float, var fy: Float) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(0xAA000000.toInt())
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x33FFFFFF
        for (i in 1..9) { c.drawLine(w * i / 10f, 0f, w * i / 10f, h, p); c.drawLine(0f, h * i / 10f, w, h * i / 10f, p) }
        val x = fx * w; val y = fy * h
        p.color = TEAL; p.strokeWidth = 2 * d
        c.drawLine(x, 0f, x, h, p); c.drawLine(0f, y, w, y, p); c.drawCircle(x, y, 22 * d, p)
        p.style = Paint.Style.FILL; p.textSize = 16 * d
        c.drawText(String.format(Locale.US, "X %.1f%%   Y %.1f%%", fx * 100, fy * 100), 16 * d, 28 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        fx = ((e.x / width).coerceIn(0f, 1f) * 1000).roundToInt() / 1000f
        fy = ((e.y / height).coerceIn(0f, 1f) * 1000).roundToInt() / 1000f
        invalidate()
        return true
    }
}
