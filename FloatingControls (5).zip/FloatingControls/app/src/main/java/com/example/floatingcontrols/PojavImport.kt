package com.example.floatingcontrols

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/** Converts a PojavLauncher-style control map (mControlDataList ...) into this app's buttons. */
object PojavImport {
    fun isPojav(j: JSONObject) = j.has("mControlDataList")

    fun convert(ctx: Context, root: JSONObject): MutableList<Btn> {
        val s = screenSize(ctx)
        val sw = max(s.first, s.second).toDouble()
        val sh = min(s.first, s.second).toDouble()
        val d = ctx.resources.displayMetrics.density.toDouble()
        val out = mutableListOf<Btn>()
        val buttons = root.optJSONArray("mControlDataList") ?: JSONArray()
        for (i in 0 until buttons.length()) out.add(one(buttons.getJSONObject(i), false, sw, sh, d))
        val joys = root.optJSONArray("mJoystickDataList") ?: JSONArray()
        for (i in 0 until joys.length()) out.add(one(joys.getJSONObject(i), true, sw, sh, d))
        return out
    }

    private fun one(o: JSONObject, joy: Boolean, sw: Double, sh: Double, d: Double): Btn {
        val b = Btn.create(if (joy) "joystick" else "button", o.optString("name", "BTN"))
        val wDp = o.optDouble("width", 80.0)
        val hDp = o.optDouble("height", 80.0)
        b.w = wDp.toInt().coerceIn(24, 2000)
        b.h = hDp.toInt().coerceIn(24, 2000)
        val wpx = wDp * d
        val hpx = hDp * d
        val vars = mapOf(
            "screen_width" to sw, "screen_height" to sh, "margin" to 2 * d,
            "width" to wpx, "height" to hpx, "right" to sw - wpx, "bottom" to sh - hpx,
            "preferred_scale" to 100.0
        )
        val x = eval(o.optString("dynamicX", "0"), vars, d)
        val y = eval(o.optString("dynamicY", "0"), vars, d)
        b.x = (x / sw).toFloat().coerceIn(0f, 0.98f)
        b.y = (y / sh).toFloat().coerceIn(0f, 0.98f)

        b.bg = o.optInt("bgColor", b.bg)
        b.stroke = o.optInt("strokeColor", b.stroke)
        b.strokeW = o.optDouble("strokeWidth", 0.0).toInt().coerceIn(0, 100)
        val cr = o.optDouble("cornerRadius", 0.0).toInt().coerceIn(0, 100)
        b.corner = cr
        b.shape = if (joy) "circle" else if (cr > 0) "rounded" else "rect"
        b.opacity = (o.optDouble("opacity", 1.0) * 100).toInt().coerceIn(10, 100)
        b.inGame = o.optBoolean("displayInGame", true)
        b.inMenus = o.optBoolean("displayInMenu", true)
        b.passThru = o.optBoolean("passThruEnabled", false)
        b.slide = o.optBoolean("isSwipeable", false)
        val toggle = o.optBoolean("isToggle", false)

        if (joy) {
            val m = min(b.w, b.h)
            b.w = m; b.h = m
            b.act(0).action = "KEY"          // Pojav joysticks send W A S D
            b.slide = false
        } else {
            val kc = o.optJSONArray("keycodes")
            var slot = 0
            val n = kc?.length() ?: 0
            for (k in 0 until n) {
                val code = kc?.optInt(k, 0) ?: 0
                if (code == 0 || slot > 3) continue
                if (fill(b.act(slot), code, toggle)) slot++
            }
            if (slot == 0) b.act(0).action = "NONE"
        }
        return b
    }

    private fun fill(a: Act, code: Int, toggle: Boolean): Boolean {
        when {
            code > 0 -> {
                val n = if (code == KeyEvent.KEYCODE_BACK) "ESCAPE" else KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
                if (KeyEvent.keyCodeToString(code).startsWith("KEYCODE_").not()) return false
                a.action = "KEY"; a.key = n; a.toggle = toggle
            }
            code == -2 -> { a.action = "SYSTEM"; a.system = "TOGGLE_CONTROLS" }          // show/hide controls
            code == -3 -> { a.action = "HOLD"; a.tx = 50f; a.ty = 50f; a.toggle = toggle } // left mouse = hold touch
            code == -4 -> { a.action = "TAP"; a.tx = 50f; a.ty = 50f }                     // right mouse = tap
            else -> return false                                                           // keyboard, virtual mouse, scroll
        }
        return true
    }

    private fun eval(expr: String, vars: Map<String, Double>, d: Double): Double {
        return try {
            var s = expr
            for ((k, v) in vars) s = s.replace("\${" + k + "}", "(" + v + ")")
            Parser(s, d).parse()
        } catch (e: Exception) { 0.0 }
    }

    private class Parser(private val s: String, private val d: Double) {
        private var i = 0
        fun parse(): Double = expr()

        private fun ws() { while (i < s.length && s[i] == ' ') i++ }
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                val c = peek()
                if (c == '+') { i++; v += term() } else if (c == '-') { i++; v -= term() } else return v
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                ws()
                val c = peek()
                if (c == '*') { i++; v *= unary() } else if (c == '/') { i++; v /= unary() } else return v
            }
        }

        private fun unary(): Double {
            ws()
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return atom()
        }

        private fun atom(): Double {
            ws()
            if (peek() == '(') {
                i++
                val v = expr()
                ws()
                if (peek() == ')') i++
                return v
            }
            if (s.startsWith("px(", i)) {
                i += 3
                val v = expr()
                ws()
                if (peek() == ')') i++
                return v * d
            }
            val st = i
            while (i < s.length) {
                val c = s[i]
                val expSign = (c == '-' || c == '+') && i > st && (s[i - 1] == 'E' || s[i - 1] == 'e')
                if (c.isDigit() || c == '.' || c == 'E' || c == 'e' || expSign) i++ else break
            }
            return s.substring(st, i).toDouble()
        }
    }
}
