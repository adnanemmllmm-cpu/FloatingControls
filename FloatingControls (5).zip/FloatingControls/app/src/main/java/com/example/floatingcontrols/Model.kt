package com.example.floatingcontrols

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.reflect.KProperty

/** JSON-backed property delegate: every setting lives in the button's JSONObject. */
class P<T : Any>(private val key: String, private val def: T) {
    @Suppress("UNCHECKED_CAST")
    operator fun getValue(b: Btn, p: KProperty<*>): T = when (def) {
        is Int -> b.j.optInt(key, def)
        is Float -> b.j.optDouble(key, def.toDouble()).toFloat()
        is Boolean -> b.j.optBoolean(key, def)
        else -> b.j.optString(key, def as String)
    } as T

    operator fun setValue(b: Btn, p: KProperty<*>, v: T) { b.j.put(key, v) }
}

/** Same as P but for one of a button's 4 function slots (slot 0 keeps the original key names). */
class Q<T : Any>(private val key: String, private val def: T) {
    @Suppress("UNCHECKED_CAST")
    operator fun getValue(a: Act, p: KProperty<*>): T {
        val k = a.k(key)
        return when (def) {
            is Int -> a.j.optInt(k, def)
            is Float -> a.j.optDouble(k, def.toDouble()).toFloat()
            is Boolean -> a.j.optBoolean(k, def)
            else -> a.j.optString(k, def as String)
        } as T
    }

    operator fun setValue(a: Act, p: KProperty<*>, v: T) { a.j.put(a.k(key), v) }
}

/** One function slot (0..3) of a button. All enabled slots fire together when the button is pressed. */
class Act(val j: JSONObject, val n: Int) {
    fun k(key: String) = if (n == 0) key else key + "_" + n
    var action by Q("action", if (n == 0) "TAP" else "NONE") // NONE TAP LONG_PRESS HOLD REPEAT_TAP SWIPE SEQUENCE SYSTEM
    var tx by Q("tx", 50f)                   // target, % of screen
    var ty by Q("ty", 50f)
    var tx2 by Q("tx2", 60f)                 // swipe end, % of screen
    var ty2 by Q("ty2", 50f)
    var duration by Q("duration", 500)       // ms (long press / swipe)
    var interval by Q("interval", 100)       // ms (repeat)
    var sequence by Q("sequence", "")
    var system by Q("system", "BACK")
    var pkg by Q("pkg", "")
    var toggle by Q("toggle", false)
    var swipeable by Q("swipeable", false)
    var key by Q("key", "F3")                // keyboard key name (KEYCODE_ suffix)
    var keyTap by Q("keyTap", false)         // quick press instead of holding while pressed
}

/** One floating element (button or joystick). Each has fully independent settings. */
class Btn(val j: JSONObject = JSONObject()) {
    var id by P("id", "")
    var kind by P("kind", "button")          // "button" | "joystick"
    var name by P("name", "BTN")
    var x by P("x", 0.4f)                    // top-left, fraction of screen width
    var y by P("y", 0.35f)                   // top-left, fraction of screen height
    var w by P("w", 90)                      // dp
    var h by P("h", 90)                      // dp
    var shape by P("shape", "rounded")       // rect | square | circle | rounded
    var bg by P("bg", 0xCC202020.toInt())
    var fg by P("fg", 0xFFFFFFFF.toInt())
    var stroke by P("stroke", 0xFFFFFFFF.toInt())
    var strokeW by P("strokeW", 10)          // 0..100 %
    var corner by P("corner", 25)            // 0..100 %
    var opacity by P("opacity", 100)         // 10..100 %
    var image by P("image", "")              // background image file path
    var passThru by P("passThru", false)
    var inGame by P("inGame", true)
    var inMenus by P("inMenus", true)
    var slide by P("slide", false)           // swipeable: slide a finger from this button onto other swipeable buttons
    var reach by P("reach", 90)              // joystick reach in game, dp

    fun act(i: Int) = Act(j, i)

    fun copy(): Btn {
        val c = Btn(JSONObject(j.toString()))
        c.id = UUID.randomUUID().toString()
        c.x = minOf(x + 0.03f, 0.9f)
        c.y = minOf(y + 0.05f, 0.9f)
        return c
    }

    companion object {
        fun create(kind: String, name: String): Btn {
            val b = Btn()
            b.id = UUID.randomUUID().toString()
            b.kind = kind
            b.name = name
            if (kind == "joystick") {
                b.shape = "circle"; b.w = 150; b.h = 150
                b.bg = 0x55303030.toInt()
                b.act(0).action = "NONE"; b.act(0).tx = 15f; b.act(0).ty = 70f
                b.x = 0.06f; b.y = 0.5f; b.opacity = 90
            }
            return b
        }
    }
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("fc", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "profiles").apply { mkdirs() }
    fun clean(n: String) = n.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim()
    private fun file(c: Context, n: String) = File(dir(c), clean(n) + ".json")

    fun names(c: Context): List<String> =
        dir(c).listFiles()?.map { it.name.removeSuffix(".json") }?.sorted() ?: emptyList()

    fun active(c: Context): String = prefs(c).getString("active", "Default") ?: "Default"
    fun setActive(c: Context, n: String) { prefs(c).edit().putString("active", n).apply() }
    fun enabled(c: Context) = prefs(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) { prefs(c).edit().putBoolean("enabled", v).apply() }
    fun seenIntro(c: Context) = prefs(c).getBoolean("seen", false)
    fun setSeenIntro(c: Context) { prefs(c).edit().putBoolean("seen", true).apply() }
    fun mainPos(c: Context) = Pair(prefs(c).getFloat("fabx", 0.47f), prefs(c).getFloat("faby", 0.02f))
    fun setMainPos(c: Context, x: Float, y: Float) { prefs(c).edit().putFloat("fabx", x).putFloat("faby", y).apply() }

    fun load(c: Context, n: String): MutableList<Btn> {
        val f = file(c, n)
        if (!f.exists()) return if (n == "Default") defaults().also { save(c, n, it) } else mutableListOf()
        return parse(f.readText())
    }

    fun parse(s: String): MutableList<Btn> {
        val a = JSONObject(s).getJSONArray("buttons")
        return MutableList(a.length()) { Btn(a.getJSONObject(it)) }
    }

    fun toJson(name: String, list: List<Btn>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it.j) }
        return JSONObject().put("name", name).put("version", 1).put("buttons", arr).toString(2)
    }

    fun save(c: Context, n: String, list: List<Btn>) { file(c, n).writeText(toJson(n, list)) }
    fun delete(c: Context, n: String) { file(c, n).delete() }

    private fun defaults(): MutableList<Btn> {
        val l = mutableListOf<Btn>()
        l.add(Btn.create("joystick", "MOVE"))
        l.add(Btn.create("button", "JUMP").also {
            it.x = 0.85f; it.y = 0.55f; it.w = 80; it.h = 80; it.shape = "circle"; it.corner = 50
            it.act(0).action = "TAP"; it.act(0).tx = 88f; it.act(0).ty = 65f; it.bg = 0xCC1B5E20.toInt()
        })
        l.add(Btn.create("button", "BREAK").also {
            it.x = 0.72f; it.y = 0.62f
            it.act(0).action = "HOLD"; it.act(0).swipeable = true
            it.act(0).tx = 50f; it.act(0).ty = 50f; it.bg = 0xCC6A1B1A.toInt()
        })
        l.add(Btn.create("button", "BACK").also {
            it.x = 0.02f; it.y = 0.05f; it.w = 70; it.h = 44; it.shape = "rect"; it.corner = 0
            it.act(0).action = "SYSTEM"; it.act(0).system = "BACK"
        })
        return l
    }
}
