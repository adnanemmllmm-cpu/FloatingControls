package com.example.floatingcontrols

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.reflect.KMutableProperty0

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    companion object { const val REQ_IMG = 1; const val REQ_IMPORT = 2; const val REQ_EXPORT = 3 }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var ws: Workspace
    private lateinit var menu: LinearLayout
    private lateinit var menuScroll: ScrollView
    private lateinit var panelScroll: ScrollView
    private lateinit var panel: LinearLayout
    private lateinit var actions: LinearLayout
    private lateinit var cog: TextView
    private lateinit var infoView: TextView
    private lateinit var previewBar: LinearLayout
    private lateinit var ctrlSwitch: Switch

    private var profile = "Default"
    private var items = mutableListOf<Btn>()
    private var selected: Btn? = null
    private var preview = false
    private var updating = false
    private var syncing = false
    private var wEdit: EditText? = null
    private var hEdit: EditText? = null
    private var imgTarget: Btn? = null
    private val saveTask = Runnable { save() }

    private val actionKeys = listOf("NONE", "TAP", "LONG_PRESS", "HOLD", "REPEAT_TAP", "SWIPE", "SEQUENCE", "SYSTEM")
    private val actionNames = listOf("None", "Tap at point", "Long press at point", "Hold (press & hold at point)",
        "Repeated taps", "Swipe", "Sequence of touches", "System / shortcut action")
    private val sysKeys = listOf("BACK", "HOME", "RECENTS", "NOTIFICATIONS", "QUICK_SETTINGS", "POWER_DIALOG",
        "LOCK_SCREEN", "TAKE_SCREENSHOT", "TOGGLE_CONTROLS", "LAUNCH_APP")
    private val sysNames = listOf("Back", "Home", "Recent apps", "Notifications", "Quick settings", "Power menu",
        "Lock screen", "Take screenshot", "Show/hide floating controls", "Launch an app")
    private val shapeKeys = listOf("rect", "square", "circle", "rounded")
    private val shapeNames = listOf("Rectangle", "Square", "Circle", "Rounded rectangle")

    // ------------------------------------------------------------------ setup
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val a = window.attributes
        a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = a
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)

        root = FrameLayout(this)
        root.setBackgroundColor(0xFF121212.toInt())
        ws = Workspace(this)
        root.addView(ws, FrameLayout.LayoutParams(MATCH, MATCH))
        ws.setOnClickListener { select(null); showMenu(false) }

        infoView = TextView(this)
        infoView.textSize = 12f
        infoView.setTextColor(0xB3FFFFFF.toInt())
        root.addView(infoView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { setMargins(dp(12), dp(8), 0, 0) })

        actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.visibility = View.GONE
        actions.addView(actionBtn("DELETE") { deleteSelected() })
        actions.addView(actionBtn("CLONE") { cloneSelected() })
        root.addView(actions, FrameLayout.LayoutParams(WRAP, WRAP))

        buildMenu()

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(10), dp(16), dp(16))
        panelScroll = ScrollView(this)
        panelScroll.addView(panel)
        panelScroll.visibility = View.GONE
        panelScroll.background = GradientDrawable().apply { setColor(0xFF1B1B1B.toInt()); cornerRadius = dp(12).toFloat() }
        root.addView(panelScroll, FrameLayout.LayoutParams(dp(300), MATCH, Gravity.END).apply { setMargins(0, dp(10), dp(10), dp(10)) })

        cog = TextView(this)
        cog.text = "\u2699"; cog.textSize = 26f; cog.gravity = Gravity.CENTER
        cog.setTextColor(0xFFBDBDBD.toInt())
        cog.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2A2A2A.toInt()) }
        cog.setOnClickListener { showMenu(menuScroll.visibility != View.VISIBLE) }
        root.addView(cog, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        previewBar = LinearLayout(this)
        previewBar.orientation = LinearLayout.HORIZONTAL
        previewBar.gravity = Gravity.CENTER_VERTICAL
        previewBar.setBackgroundColor(0xCC000000.toInt())
        previewBar.setPadding(dp(12), dp(4), dp(12), dp(4))
        previewBar.visibility = View.GONE
        previewBar.addView(tv("Preview: this is how the floating controls will look.  ", 13f))
        previewBar.addView(btn("Exit preview") { setPreview(false) })
        previewBar.addView(btn("Activate") { setPreview(false); setControls(true) })
        root.addView(previewBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        setContentView(root)
        loadProfile(Store.active(this))
        if (!Store.seenIntro(this)) { Store.setSeenIntro(this); showPermissions() }
    }

    private fun immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) immersive() }
    override fun onResume() { super.onResume(); syncSwitch(OverlayService.instance != null) }
    override fun onPause() { h.removeCallbacks(saveTask); save(); super.onPause() }

    override fun onBackPressed() {
        when {
            preview -> setPreview(false)
            menuScroll.visibility == View.VISIBLE -> showMenu(false)
            panelScroll.visibility == View.VISIBLE -> select(null)
            else -> finish()
        }
    }

    // ------------------------------------------------------------------ small UI helpers
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(t: String, sp: Float = 16f, col: Int = 0xFFE0E0E0.toInt()) =
        TextView(this).apply { text = t; textSize = sp; setTextColor(col) }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }

    private fun actionBtn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        setBackgroundColor(0xFF616161.toInt()); setPadding(dp(18), dp(8), dp(18), dp(8))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) }
        setOnClickListener { f() }
    }

    private fun LinearLayout.label(t: String) {
        addView(tv(t, 13f, 0xFF9E9E9E.toInt()).apply { setPadding(0, dp(12), 0, dp(2)) })
    }

    private fun mkEdit(v: String, num: Boolean, cb: (String) -> Unit) = EditText(this).apply {
        setText(v); setSingleLine(); setTextColor(Color.WHITE)
        imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_DONE
        if (num) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        addTextChangedListener(Watcher { if (!updating) cb(it) })
    }

    private fun LinearLayout.row2(a: View, b: View) {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        r.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(r)
    }

    private fun LinearLayout.spin(names: List<String>, sel: Int, cb: (Int) -> Unit) {
        val s = Spinner(context)
        s.adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, names)
        s.setSelection(sel.coerceAtLeast(0))
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (pos != sel) cb(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        addView(s)
    }

    private fun LinearLayout.sw(t: String, v: Boolean, cb: (Boolean) -> Unit) {
        val s = Switch(context)
        s.text = t; s.isChecked = v; s.setTextColor(0xFFE0E0E0.toInt()); s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, c -> cb(c) }
        addView(s)
    }

    private fun LinearLayout.chk(t: String, v: Boolean, cb: (Boolean) -> Unit) {
        val s = CheckBox(context)
        s.text = t; s.isChecked = v; s.setTextColor(0xFFE0E0E0.toInt())
        s.setOnCheckedChangeListener { _, c -> cb(c) }
        addView(s)
    }

    private fun LinearLayout.seek(t: String, v: Int, min: Int, cb: (Int) -> Unit) {
        val label = tv("$t  $v%", 15f)
        label.setPadding(0, dp(10), 0, 0)
        addView(label)
        val s = SeekBar(context)
        s.max = 100; s.progress = v
        s.progressTintList = ColorStateList.valueOf(TEAL)
        s.thumbTintList = ColorStateList.valueOf(TEAL)
        s.setOnSeekBarChangeListener(Seek { p -> val q = max(p, min); cb(q); label.text = "$t  $q%" })
        addView(s)
    }

    private fun LinearLayout.colorRow(t: String, get: () -> Int, set: (Int) -> Unit) {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        r.addView(tv(t, 16f), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = View(context)
        sw.setBackgroundColor(get())
        r.addView(sw, LinearLayout.LayoutParams(dp(36), dp(22)))
        r.setOnClickListener { pickColor(get()) { c -> set(c); sw.setBackgroundColor(c) } }
        addView(r)
    }

    private fun LinearLayout.navRow(t: String, f: () -> Unit) {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL; r.setPadding(0, dp(10), 0, dp(10))
        r.addView(tv(t, 16f), LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(tv("\u203A", 22f))
        r.setOnClickListener { f() }
        addView(r)
    }

    private fun fmt(f: Float) = if (f % 1f == 0f) f.toInt().toString() else String.format(Locale.US, "%.1f", f)

    private fun LinearLayout.numField(t: String, p: KMutableProperty0<Int>, min: Int) {
        label(t)
        addView(mkEdit(p.get().toString(), true) { s ->
            val v = s.toFloatOrNull()
            if (v != null) { p.set(v.toInt().coerceAtLeast(min)); markDirty() }
        })
    }

    private fun LinearLayout.pt(title: String, px: KMutableProperty0<Float>, py: KMutableProperty0<Float>) {
        label("$title  (X / Y in % of screen)")
        val ex = mkEdit(fmt(px.get()), true) { s -> s.toFloatOrNull()?.let { px.set(it.coerceIn(0f, 100f)); markDirty() } }
        val ey = mkEdit(fmt(py.get()), true) { s -> s.toFloatOrNull()?.let { py.set(it.coerceIn(0f, 100f)); markDirty() } }
        row2(ex, ey)
        addView(btn("Pick on screen (drag target)") {
            pickPoint(px.get(), py.get()) { nx, ny ->
                px.set(nx); py.set(ny); ex.setText(fmt(nx)); ey.setText(fmt(ny)); markDirty()
            }
        })
    }

    // ------------------------------------------------------------------ side menu
    private fun buildMenu() {
        menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        menu.setBackgroundColor(0xFF2E2E2E.toInt())
        menuScroll = ScrollView(this)
        menuScroll.addView(menu)
        menuScroll.visibility = View.GONE
        root.addView(menuScroll, FrameLayout.LayoutParams(dp(260), MATCH, Gravity.END))

        val lp = { LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = 1 } }
        ctrlSwitch = Switch(this)
        ctrlSwitch.text = "Floating controls"; ctrlSwitch.textSize = 18f
        ctrlSwitch.setTextColor(0xFFEEEEEE.toInt())
        ctrlSwitch.setPadding(dp(20), dp(14), dp(20), dp(14))
        ctrlSwitch.setBackgroundColor(0xFF424242.toInt())
        ctrlSwitch.setOnCheckedChangeListener { _, c -> if (!syncing) setControls(c) }
        menu.addView(ctrlSwitch, lp())

        fun item(t: String, f: () -> Unit) {
            val v = tv(t, 18f, 0xFFEEEEEE.toInt())
            v.setPadding(dp(20), dp(14), dp(20), dp(14))
            v.setBackgroundColor(0xFF424242.toInt())
            v.setOnClickListener { showMenu(false); f() }
            menu.addView(v, lp())
        }
        item("Add button") { addItem("button") }
        item("Add joystick") { addItem("joystick") }
        item("Preview controls") { setPreview(true) }
        item("Load profile") { loadDialog() }
        item("Save") { save(); toast("Saved \"$profile\"") }
        item("Save as new profile") { saveAsDialog(false) }
        item("New empty profile") { saveAsDialog(true) }
        item("Delete profile") { deleteProfile() }
        item("Import controlmap") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT)
        }
        item("Export controlmap") {
            save()
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "$profile.json"), REQ_EXPORT)
        }
        item("Permissions & help") { showPermissions() }
    }

    private fun showMenu(show: Boolean) {
        menuScroll.visibility = if (show) View.VISIBLE else View.GONE
        if (show) select(null)
    }

    // ------------------------------------------------------------------ profiles / saving
    private fun refreshInfo() {
        infoView.text = "Profile: $profile  |  Controls: ${if (OverlayService.instance != null) "ON" else "OFF"}\n" +
            "Tap \u2699 for the menu. Tap a button to edit it, drag to move, drag its corner to resize."
        infoView.visibility = if (preview) View.GONE else View.VISIBLE
    }

    private fun save() {
        try { Store.save(this, profile, items) } catch (e: Exception) { toast("Save failed: ${e.message}") }
        OverlayService.instance?.reload()
    }

    private fun markDirty() { h.removeCallbacks(saveTask); h.postDelayed(saveTask, 500) }

    private fun loadProfile(name: String) {
        profile = name
        Store.setActive(this, name)
        items = try { Store.load(this, name) } catch (e: Exception) { toast("Could not read profile"); mutableListOf() }
        ws.removeAllViews()
        items.forEach { addViewFor(it) }
        select(null)
        refreshInfo()
        OverlayService.instance?.reload()
    }

    private fun loadDialog() {
        val names = Store.names(this).toTypedArray()
        AlertDialog.Builder(this).setTitle("Load profile (also used by the floating overlay)")
            .setItems(names) { _, i -> h.removeCallbacks(saveTask); save(); loadProfile(names[i]) }.show()
    }

    private fun saveAsDialog(empty: Boolean) {
        val et = EditText(this)
        et.setSingleLine(); et.setTextColor(Color.WHITE); et.hint = "Profile name"
        et.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
        AlertDialog.Builder(this).setTitle(if (empty) "New empty profile" else "Save as new profile").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = Store.clean(et.text.toString())
                if (n.isBlank()) { toast("Enter a name"); return@setPositiveButton }
                h.removeCallbacks(saveTask); save()
                Store.save(this, n, if (empty) emptyList() else items)
                loadProfile(n)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteProfile() {
        if (Store.names(this).size <= 1) { toast("You can't delete the only profile"); return }
        AlertDialog.Builder(this).setTitle("Delete profile \"$profile\"?")
            .setPositiveButton("Delete") { _, _ ->
                h.removeCallbacks(saveTask)
                Store.delete(this, profile)
                loadProfile(Store.names(this).first())
            }.setNegativeButton("Cancel", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        try {
            when (req) {
                REQ_IMG -> imgTarget?.let { b -> saveImage(uri, b); viewOf(b)?.refresh(); markDirty() }
                REQ_EXPORT -> {
                    contentResolver.openOutputStream(uri)?.use { it.write(Store.toJson(profile, items).toByteArray()) }
                    toast("Exported")
                }
                REQ_IMPORT -> {
                    val txt = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
                    val list = Store.parse(txt)
                    var base = Store.clean(JSONObject(txt).optString("name", "Imported"))
                    if (base.isBlank()) base = "Imported"
                    var n = base
                    var k = 2
                    while (Store.names(this).contains(n)) { n = "$base-$k"; k++ }
                    h.removeCallbacks(saveTask); save()
                    Store.save(this, n, list)
                    loadProfile(n)
                    toast("Imported as \"$n\"")
                }
            }
        } catch (e: Exception) { toast("Failed: ${e.message}") }
    }

    private fun saveImage(uri: Uri, b: Btn) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2
        val bm = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return
        val f = File(File(filesDir, "img").apply { mkdirs() }, b.id + "_" + System.currentTimeMillis() + ".png")
        FileOutputStream(f).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
        b.image = f.absolutePath
    }

    // ------------------------------------------------------------------ workspace
    private fun viewOf(b: Btn): ElementView? = ws.views().firstOrNull { it.cfg === b }

    private fun addViewFor(b: Btn) {
        val v = ElementView(this, b, if (preview) ElementView.PREVIEW else ElementView.EDIT)
        v.onSelect = { select(it) }
        v.onChange = { onElementChanged(it) }
        v.refresh()
        ws.addView(v, FrameLayout.LayoutParams(dp(b.w), dp(b.h)))
        ws.place(v)
    }

    private fun addItem(kind: String) {
        val b = Btn.create(kind, if (kind == "joystick") "MOVE" else "BTN${items.size + 1}")
        items.add(b)
        addViewFor(b)
        select(b)
        markDirty()
    }

    private fun deleteSelected() {
        val b = selected ?: return
        items.remove(b)
        viewOf(b)?.let { ws.removeView(it) }
        select(null)
        markDirty()
    }

    private fun cloneSelected() {
        val b = selected ?: return
        val c = b.copy()
        items.add(c)
        addViewFor(c)
        select(c)
        markDirty()
    }

    private fun select(b: Btn?) {
        if (b != null && b === selected && panelScroll.visibility == View.VISIBLE) { positionActions(); return }
        selected = b
        ws.views().forEach { it.picked = it.cfg === b }
        if (b != null) {
            menuScroll.visibility = View.GONE
            buildPanel(b)
            panelScroll.visibility = View.VISIBLE
        } else {
            panelScroll.visibility = View.GONE
        }
        positionActions()
    }

    private fun positionActions() {
        val v = selected?.let { viewOf(it) }
        if (v == null || preview) { actions.visibility = View.GONE; return }
        actions.visibility = View.VISIBLE
        actions.post {
            actions.x = v.x.coerceIn(0f, max(0f, root.width - actions.width.toFloat()))
            var ay = v.y - actions.height
            if (ay < 0) ay = v.y + v.height
            actions.y = ay
        }
    }

    private fun onElementChanged(b: Btn) {
        if (b === selected) syncSizeFields(b)
        positionActions()
        markDirty()
    }

    private fun syncSizeFields(b: Btn) {
        updating = true
        wEdit?.let { if (!it.hasFocus()) it.setText(b.w.toString()) }
        hEdit?.let { if (!it.hasFocus()) it.setText(b.h.toString()) }
        updating = false
    }

    private fun resize(b: Btn) {
        val v = viewOf(b) ?: return
        val lp = v.layoutParams
        lp.width = dp(b.w); lp.height = dp(b.h)
        v.layoutParams = lp
        positionActions()
        markDirty()
    }

    private fun setPreview(on: Boolean) {
        preview = on
        select(null)
        showMenu(false)
        ws.views().forEach { it.mode = if (on) ElementView.PREVIEW else ElementView.EDIT; it.refresh() }
        previewBar.visibility = if (on) View.VISIBLE else View.GONE
        cog.visibility = if (on) View.GONE else View.VISIBLE
        refreshInfo()
    }

    // ------------------------------------------------------------------ customization panel
    private fun buildPanel(b: Btn) {
        panel.removeAllViews()
        val joy = b.kind == "joystick"
        val changed = { viewOf(b)?.refresh(); markDirty() }
        panel.apply {
            val top = LinearLayout(context)
            top.orientation = LinearLayout.HORIZONTAL
            top.addView(tv(if (joy) "Joystick" else "Button", 18f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
            top.addView(tv("\u2715", 20f).apply { setPadding(dp(12), 0, dp(4), 0); setOnClickListener { select(null) } })
            addView(top)

            if (!joy) { label("Name"); addView(mkEdit(b.name, false) { b.name = it; changed() }) }

            label("Size (dp)")
            val sq = joy || b.shape == "square" || b.shape == "circle"
            val we = mkEdit(b.w.toString(), true) { s ->
                val v = s.toFloatOrNull()
                if (v != null) {
                    b.w = v.toInt().coerceIn(24, 2000)
                    if (sq) b.h = b.w
                    resize(b); syncSizeFields(b)
                }
            }
            val he = mkEdit(b.h.toString(), true) { s ->
                val v = s.toFloatOrNull()
                if (v != null && !sq) { b.h = v.toInt().coerceIn(24, 2000); resize(b) }
            }
            he.isEnabled = !sq
            wEdit = we; hEdit = he
            row2(we, he)

            if (!joy) {
                label("Shape")
                spin(shapeNames, shapeKeys.indexOf(b.shape)) { i ->
                    b.shape = shapeKeys[i]
                    when (b.shape) {
                        "rect", "square" -> b.corner = 0
                        "rounded" -> b.corner = 25
                        else -> b.corner = 50
                    }
                    if (b.shape == "square" || b.shape == "circle") b.h = b.w
                    resize(b); changed()
                    h.post { buildPanel(b) }
                }
                label("Action")
                spin(actionNames, actionKeys.indexOf(b.action)) { i ->
                    b.action = actionKeys[i]; markDirty()
                    h.post { buildPanel(b) }
                }
            }

            if (joy) {
                pt("Joystick centre in the game", b::tx, b::ty)
                numField("Reach in the game (dp)", b::reach, 10)
            } else {
                when (b.action) {
                    "TAP", "HOLD" -> pt("Touch point", b::tx, b::ty)
                    "LONG_PRESS" -> { pt("Touch point", b::tx, b::ty); numField("Hold time (ms)", b::duration, 50) }
                    "REPEAT_TAP" -> { pt("Touch point", b::tx, b::ty); numField("Interval (ms)", b::interval, 30) }
                    "SWIPE" -> {
                        pt("Swipe start", b::tx, b::ty)
                        pt("Swipe end", b::tx2, b::ty2)
                        numField("Swipe duration (ms)", b::duration, 50)
                    }
                    "SEQUENCE" -> {
                        label("Sequence")
                        addView(btn("Edit sequence (${b.sequence.lines().count { it.isNotBlank() }} steps)") { editSequence(b, b.sequence) })
                    }
                    "SYSTEM" -> {
                        label("System action")
                        spin(sysNames, sysKeys.indexOf(b.system)) { i ->
                            b.system = sysKeys[i]; markDirty()
                            h.post { buildPanel(b) }
                        }
                        if (b.system == "LAUNCH_APP") {
                            label("Package name (e.g. com.mojang.minecraftpe)")
                            addView(mkEdit(b.pkg, false) { b.pkg = it; markDirty() })
                        }
                    }
                }
            }

            if (!joy) sw("Toggleable (Hold / Repeat / Sequence stay on until tapped again)", b.toggle) { b.toggle = it; markDirty() }
            sw("Mouse pass-thru (touches go straight through to the app)", b.passThru) { b.passThru = it; markDirty() }
            if (!joy) sw("Swipeable (a Hold follows your finger, e.g. camera look)", b.swipeable) { b.swipeable = it; markDirty() }

            navRow("Background image") {
                imgTarget = b
                AlertDialog.Builder(this@MainActivity).setItems(arrayOf("Choose image\u2026", "Clear image")) { _, i ->
                    if (i == 0) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_IMG)
                    else { b.image = ""; changed() }
                }.show()
            }
            colorRow("Background color", { b.bg }) { b.bg = it; changed() }
            if (!joy) colorRow("Text color", { b.fg }) { b.fg = it; changed() }
            else colorRow("Knob color", { b.fg }) { b.fg = it; changed() }
            colorRow("Stroke color", { b.stroke }) { b.stroke = it; changed() }
            seek("Stroke width", b.strokeW, 0) { b.strokeW = it; changed() }
            if (!joy && b.shape != "circle") seek("Corner radius", b.corner, 0) { b.corner = it; changed() }
            seek("Button opacity", b.opacity, 10) { b.opacity = it; changed() }

            label("Visibility  (switch mode from the main floating button's long-press menu)")
            chk("In-game", b.inGame) { b.inGame = it; markDirty() }
            chk("In menus", b.inMenus) { b.inMenus = it; markDirty() }
        }
    }

    // ------------------------------------------------------------------ dialogs
    private fun pickColor(initial: Int, apply: (Int) -> Unit) {
        val c = intArrayOf(Color.alpha(initial), Color.red(initial), Color.green(initial), Color.blue(initial))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val sw = View(this)
        fun cur() = Color.argb(c[0], c[1], c[2], c[3])
        sw.setBackgroundColor(cur())
        box.addView(sw, LinearLayout.LayoutParams(MATCH, dp(36)))
        listOf("Opacity (alpha)", "Red", "Green", "Blue").forEachIndexed { i, n ->
            box.addView(tv(n, 13f))
            val s = SeekBar(this)
            s.max = 255; s.progress = c[i]
            s.setOnSeekBarChangeListener(Seek { p -> c[i] = p; sw.setBackgroundColor(cur()); apply(cur()) })
            box.addView(s)
        }
        AlertDialog.Builder(this).setTitle("Pick a color").setView(box)
            .setPositiveButton("OK", null)
            .setNegativeButton("Cancel") { _, _ -> apply(initial) }.show()
    }

    private fun pickPoint(px: Float, py: Float, done: (Float, Float) -> Unit) {
        val ov = FrameLayout(this)
        val cv = PickerView(this, px / 100f, py / 100f)
        ov.addView(cv, FrameLayout.LayoutParams(MATCH, MATCH))
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xCC000000.toInt())
        bar.setPadding(dp(12), dp(4), dp(12), dp(4))
        bar.addView(tv("Drag the crosshair to the target point.  ", 13f))
        bar.addView(btn("OK") { root.removeView(ov); done(cv.fx * 100f, cv.fy * 100f) })
        bar.addView(btn("Cancel") { root.removeView(ov) })
        ov.addView(bar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun addLine(cur: String, line: String) = (if (cur.isBlank()) "" else cur.trimEnd() + "\n") + line

    private fun editSequence(b: Btn, initial: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        box.addView(tv("One step per line (X, Y in % of screen):\ntap X Y\nlong X Y ms\nswipe X1 Y1 X2 Y2 ms\nwait ms", 12f))
        val et = EditText(this)
        et.setText(initial); et.setTextColor(Color.WHITE); et.minLines = 5; et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        et.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
        box.addView(et)
        val dlg = AlertDialog.Builder(this).setTitle("Sequence").setView(box)
            .setPositiveButton("Save") { _, _ -> b.sequence = et.text.toString().trim(); markDirty(); buildPanel(b) }
            .setNegativeButton("Cancel", null).create()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun add(t: String, f: () -> Unit) {
            val bt = btn(t, f)
            bt.textSize = 12f
            row.addView(bt, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        add("+Tap") {
            val cur = et.text.toString(); dlg.dismiss()
            pickPoint(50f, 50f) { x, y -> editSequence(b, addLine(cur, "tap ${fmt(x)} ${fmt(y)}")) }
        }
        add("+Long") {
            val cur = et.text.toString(); dlg.dismiss()
            pickPoint(50f, 50f) { x, y -> editSequence(b, addLine(cur, "long ${fmt(x)} ${fmt(y)} 800")) }
        }
        add("+Swipe") {
            val cur = et.text.toString(); dlg.dismiss()
            pickPoint(40f, 50f) { x1, y1 ->
                pickPoint(60f, 50f) { x2, y2 ->
                    editSequence(b, addLine(cur, "swipe ${fmt(x1)} ${fmt(y1)} ${fmt(x2)} ${fmt(y2)} 400"))
                }
            }
        }
        add("+Wait") { et.setText(addLine(et.text.toString(), "wait 500")); et.setSelection(et.text.length) }
        box.addView(row)
        dlg.show()
    }

    // ------------------------------------------------------------------ permissions / start-stop
    private fun showPermissions() {
        val ov = Settings.canDrawOverlays(this)
        val acc = GestureService.instance != null
        val msg = "\u2022 Display over other apps: needed to draw your floating buttons on top of Minecraft or any other app.  [" +
            (if (ov) "granted" else "not granted") + "]\n\n" +
            "\u2022 Accessibility service: Android's only way for an app to send taps, long presses and swipes for you. It is used only to perform the actions you assign to buttons; this app does not read your screen.  [" +
            (if (acc) "on" else "off") + "]\n\n" +
            "\u2022 Notifications (Android 13+): shows the \"controls are on\" notification with a Stop button.\n\n" +
            "If the Accessibility switch is greyed out (sideloaded APK): Settings > Apps > Floating Controls > \u22EE menu > Allow restricted settings, then try again.\n\n" +
            "Limits: Android cannot inject real keyboard keys without root. Buttons send touches, or system actions such as Back/Home/Recents."
        AlertDialog.Builder(this).setTitle("Permissions & help").setMessage(msg)
            .setPositiveButton("Overlay permission") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNeutralButton("Accessibility") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Close", null).show()
    }

    private fun syncSwitch(on: Boolean) {
        syncing = true
        ctrlSwitch.isChecked = on
        syncing = false
        refreshInfo()
    }

    private fun setControls(on: Boolean) {
        if (!on) {
            Store.setEnabled(this, false)
            stopService(Intent(this, OverlayService::class.java))
            syncSwitch(false)
            return
        }
        h.removeCallbacks(saveTask); save()
        if (!Settings.canDrawOverlays(this)) { syncSwitch(false); showPermissions(); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
        }
        if (GestureService.instance == null) {
            syncSwitch(false)
            AlertDialog.Builder(this).setTitle("Accessibility service is off")
                .setMessage("The buttons can be shown, but they cannot tap or swipe until you enable \"Floating Controls\" in Accessibility settings.")
                .setPositiveButton("Open settings") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Start anyway") { _, _ -> startOverlay() }.show()
            return
        }
        startOverlay()
    }

    private fun startOverlay() {
        Store.setEnabled(this, true)
        startForegroundService(Intent(this, OverlayService::class.java))
        syncSwitch(true)
        toast("Floating controls on. Tap the FC button to show/hide them.")
    }
}
