package com.example.floatingcontrols;

interface IKeyService {
    void destroy();
    void key(int keyCode, boolean down);
    void releaseAll();
}